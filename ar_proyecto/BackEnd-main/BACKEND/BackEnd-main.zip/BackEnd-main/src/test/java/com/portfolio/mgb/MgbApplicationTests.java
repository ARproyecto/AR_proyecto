package com.portfolio.mgb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MgbApplicationTests {

	@Test
	void contextLoads() {
	}

}
