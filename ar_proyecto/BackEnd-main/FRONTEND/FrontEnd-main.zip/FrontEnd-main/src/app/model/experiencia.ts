export class Experiencia {
    id? : number;
    nombreE : string;
    descripcionE : string;

    constructor(nombreE: string, descripcionE: string){
        this.nombreE = nombreE;
        this.descripcionE = descripcionE;
    }
}
