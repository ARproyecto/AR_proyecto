export class NuevoUsuario {
    nombre!: string;
    nombreUsuario!: string
    email!: string;
    password!: string;
    authorities!: string[];
}
