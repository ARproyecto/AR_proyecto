package com.arproyecto.AR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArApplicationTests {

	@Test
	void contextLoads() {
	}

}
